require([
    'jquery',
    'shufflejs',
    'domReady!'
], function ($, shufflejs) {
    'use strict';

    console.log('Hello World');

});
