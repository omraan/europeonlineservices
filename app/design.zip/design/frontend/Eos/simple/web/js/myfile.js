define(['jquery'], function($){
    "use strict";
    return function myscript()
    {
        alert("Yes, got it.");
    }
});
