function initPluginOFI() {
    if ( 'undefined' !== typeof window.objectFitImages ) {
        window.objectFitImages();
    }
}

export { initPluginOFI };
