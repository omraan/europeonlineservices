var config = {
    map: {
        '*': {
            myscript: 'js/myfile',

        }
    },
    paths: {
        rafl: './node_modules/rafl',
        fancybox: 'Eos_Base/node_modules/@fancyapps/fancybox/dist/jquery.fancybox'

    }

};
