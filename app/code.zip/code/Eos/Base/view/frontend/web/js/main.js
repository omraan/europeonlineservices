var popper = require('popper.js');
var fancybox = require('@fancyapps/fancybox');
//var swiper = require('swiper');
var animejs = require('animejs');
var throttleDebounce = require('throttle-debounce');
//var modernizr = require('modernizr');
