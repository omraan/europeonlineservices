<?php

namespace Eos\WmsPortal\Controller\Orders;

use Eos\Base\Model\ShipmentFactory;
use Magento\Customer\Model\Session;
use Magento\Framework\App\Action\Context;

class Save extends \Magento\Framework\App\Action\Action
{

    /**
     * @var Session
     */
    protected $_customerSession;

    /**
     * @var ShipmentFactory
     */

    protected $_shipment;


    public function __construct(
        Context $context,
        Session $customerSession,
        ShipmentFactory $shipment
    ) {
        $this->_customerSession = $customerSession;
        $this->_shipment = $shipment;
        parent::__construct($context);
    }
    public function execute()
    {
        $post = $this->getRequest()->getParams();
        $resultRedirect = $this->resultRedirectFactory->create();

        // Check if user is logged-in
        if ($this->_customerSession->getCustomer()->getId() > 0) {
            // Create Order Record
            $shipmentModel = $this->_shipment->create()->load($post['outbound_tracking_number'] , 'awb_code');
            if(isset($post['total_weight'])) {
                $shipmentModel->setData('total_weight', floatval($post['total_weight']));
            }
            $shipmentModel->setData('status', 'Ready for payment');
            $shipmentModel->save();

            if ($shipmentModel->save()) {
                $this->messageManager->addSuccessMessage(__('You saved the data.'));
            } else {
                $this->messageManager->addErrorMessage(__('Data was not saved.'));
            }

            $resultRedirect->setPath('wms/orders');
        } else {
            $resultRedirect->setPath('customer/account/login');
        }

        return $resultRedirect;
    }
}
